document.getElementById('startButton').addEventListener('click', async () => {
    const statusElement = document.getElementById('status');
    const button = document.getElementById('startButton');
    
    try {
        button.disabled = true;
        
        // Step 1: Cargar explicaciones
        statusElement.style.color = 'green';
        statusElement.textContent = 'Cargando explicaciones...';
        
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
                const htmlTags = document.querySelectorAll('summary.CollapsiblePanel-header');
                htmlTags.forEach(htmlTag => {
                    htmlTag.click();
                });
            }
        });

        // Add delay to ensure content is fully loaded
        statusElement.textContent = 'Esperando carga completa...';
        await new Promise(resolve => setTimeout(resolve, 2000));

        // Now capture the HTML after content is loaded
        const htmlResults = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
                return document.documentElement.outerHTML;
            }
        });

        // Step 3: Download
        statusElement.textContent = 'Preparando descarga...';
        const html = htmlResults[0].result;
        const blob = new Blob([html], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'test.html';
        a.click();
        URL.revokeObjectURL(url);

        statusElement.textContent = 'Test HTML descargado!';
        
        // Close popup after 2 seconds
        setTimeout(() => {
            window.close();
        }, 2000);

    } catch (error) {
        console.error('Error:', error);
        statusElement.style.color = 'red';
        statusElement.textContent = 'Error en el proceso';
        
        setTimeout(() => {
            window.close();
        }, 2000);
    }
});